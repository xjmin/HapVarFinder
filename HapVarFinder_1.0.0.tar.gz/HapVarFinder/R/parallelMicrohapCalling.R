#' Parallel Microhaplotype Calling by Locus Blocks
#'
#' Splits a locus-definition table into balanced blocks and runs the existing
#' \code{MicrohapCalling()} function in independent R processes. Each worker has
#' its own working directory, temporary files, BAM path, and BAM index, thereby
#' avoiding file collisions without changing the genotyping algorithm.
#'
#' @param MH_info Path to the complete tab-separated locus-definition file.
#' @param bam.file Path to a coordinate-sorted BAM file.
#' @param wd_link Output directory for combined and worker-level results.
#' @param workers Number of independent R worker processes.
#' @param threads_per_worker Number of threads passed by each worker to BAM
#'   filtering operations in \code{MicrohapCalling()}. The approximate maximum
#'   thread demand is \code{workers * threads_per_worker}.
#' @param keep_worker_outputs Whether to retain worker directories and detailed
#'   per-locus intermediate files after the combined result has been produced.
#' @param lian_qual Read quality threshold passed to \code{MicrohapCalling()}.
#' @param base_qual Base quality threshold passed to \code{MicrohapCalling()}.
#' @param base_qual_include Whether base-quality filtering is enabled.
#' @param other_snp_threshold Non-target SNP reporting threshold.
#' @param MH_read_threshold Minimum supporting read count for MH reporting.
#' @param MH_ratio_threshold Minimum haplotype ratio for MH calling.
#' @param SNP_ratio_threshold Minimum allele ratio for SNP calling.
#' @param PE_data Whether the data are paired-end ("T") or single-end ("F").
#'
#' @return A data frame containing the combined \code{MicrohapCalling()} results
#'   in the same locus order as the input file. A tab-separated copy is written
#'   to \code{Result/Parallel_combined_MHCalling.txt}.
#'
#' @details
#' On macOS and Linux, workers are launched with \code{parallel::mclapply()}.
#' On Windows, a PSOCK cluster is used. The BAM is hard-linked into each worker
#' directory when possible; if hard-linking is unavailable, it is copied. This
#' gives every worker a separate BAM filename and index path while avoiding a
#' full BAM copy on common Unix file systems.
#'
#' The function parallelizes independent locus blocks. It does not make the
#' read-level R code inside an individual locus multithreaded. For reproducible
#' scalability benchmarks, compare this function with \code{workers = 1} and
#' vary only one resource parameter at a time.
#'
#' @export
parallelMicrohapCalling <- function(
    MH_info,
    bam.file,
    wd_link,
    workers = 2L,
    threads_per_worker = 1L,
    keep_worker_outputs = TRUE,
    lian_qual = 20,
    base_qual = 30,
    base_qual_include = "T",
    other_snp_threshold = 0.01,
    MH_read_threshold = 10,
    MH_ratio_threshold = 0.25,
    SNP_ratio_threshold = 0.25,
    PE_data = "T"
) {
  if (!file.exists(MH_info)) stop("MH_info does not exist: ", MH_info)
  if (!file.exists(bam.file)) stop("bam.file does not exist: ", bam.file)

  workers <- as.integer(workers)
  threads_per_worker <- as.integer(threads_per_worker)
  if (length(workers) != 1L || is.na(workers) || workers < 1L) {
    stop("workers must be a single positive integer")
  }
  if (
    length(threads_per_worker) != 1L ||
    is.na(threads_per_worker) ||
    threads_per_worker < 1L
  ) {
    stop("threads_per_worker must be a single positive integer")
  }

  loci <- data.table::fread(MH_info, sep = "\t", header = TRUE)
  if (!nrow(loci)) stop("MH_info contains no loci")
  workers <- min(workers, nrow(loci))

  available_cores <- parallel::detectCores(logical = TRUE)
  requested_thread_budget <- workers * threads_per_worker
  if (
    !is.na(available_cores) &&
    requested_thread_budget > available_cores
  ) {
    warning(
      "workers * threads_per_worker = ", requested_thread_budget,
      ", which exceeds the detected ", available_cores,
      " logical cores and may reduce performance"
    )
  }

  dir.create(wd_link, recursive = TRUE, showWarnings = FALSE)
  worker_root <- file.path(wd_link, "Parallel_workers")
  combined_result_dir <- file.path(wd_link, "Result")
  dir.create(worker_root, recursive = TRUE, showWarnings = FALSE)
  dir.create(combined_result_dir, recursive = TRUE, showWarnings = FALSE)

  bam.file <- normalizePath(bam.file, mustWork = TRUE)

  ## Round-robin assignment balances the number of loci per worker. Original
  ## row indices are restored after worker results are combined.
  worker_ids <- ((seq_len(nrow(loci)) - 1L) %% workers) + 1L
  locus_groups <- split(seq_len(nrow(loci)), worker_ids)

  run_worker <- function(worker_id) {
    row_indices <- locus_groups[[worker_id]]
    worker_dir <- file.path(
      worker_root,
      sprintf("worker_%02d", worker_id)
    )
    dir.create(worker_dir, recursive = TRUE, showWarnings = FALSE)

    worker_locus_file <- file.path(worker_dir, "loci.tsv")
    data.table::fwrite(loci[row_indices], worker_locus_file, sep = "\t")

    ## MicrohapCalling() creates/indexes BAM files inside its locus loop. A
    ## worker-specific BAM pathname prevents concurrent index-file writes.
    worker_bam <- file.path(worker_dir, basename(bam.file))
    if (file.exists(worker_bam)) unlink(worker_bam, force = TRUE)
    linked <- file.link(from = bam.file, to = worker_bam)
    if (!isTRUE(linked)) {
      copied <- file.copy(from = bam.file, to = worker_bam, overwrite = TRUE)
      if (!isTRUE(copied)) stop("Unable to link or copy BAM for worker ", worker_id)
    }

    ## Avoid nested data.table parallelism inside multiple R workers.
    data.table::setDTthreads(1L)

    worker_result <- MicrohapCalling(
      MH_info = worker_locus_file,
      bam.file = worker_bam,
      wd_link = worker_dir,
      lian_qual = lian_qual,
      base_qual = base_qual,
      base_qual_include = base_qual_include,
      other_snp_threshold = other_snp_threshold,
      MH_read_threshold = MH_read_threshold,
      MH_ratio_threshold = MH_ratio_threshold,
      SNP_ratio_threshold = SNP_ratio_threshold,
      PE_data = PE_data,
      threads = threads_per_worker
    )

    if (nrow(worker_result) != length(row_indices)) {
      stop(
        "Worker ", worker_id, " returned ", nrow(worker_result),
        " rows for ", length(row_indices), " input loci"
      )
    }
    worker_result$.parallel_input_order <- row_indices
    worker_result
  }

  if (.Platform$OS.type == "windows") {
    cluster <- parallel::makePSOCKcluster(workers)
    on.exit(parallel::stopCluster(cluster), add = TRUE)
    worker_results <- parallel::parLapply(
      cluster,
      seq_along(locus_groups),
      run_worker
    )
  } else {
    worker_results <- parallel::mclapply(
      seq_along(locus_groups),
      run_worker,
      mc.cores = workers,
      mc.preschedule = TRUE
    )
  }

  failed_workers <- vapply(worker_results, inherits, logical(1), "try-error")
  if (any(failed_workers)) {
    stop(
      "Parallel calling failed in worker(s): ",
      paste(which(failed_workers), collapse = ", ")
    )
  }

  combined_result <- data.table::rbindlist(
    worker_results,
    use.names = TRUE,
    fill = TRUE
  )
  data.table::setorder(combined_result, .parallel_input_order)
  combined_result[, .parallel_input_order := NULL]

  combined_file <- file.path(
    combined_result_dir,
    "Parallel_combined_MHCalling.txt"
  )
  data.table::fwrite(combined_result, combined_file, sep = "\t")

  if (!isTRUE(keep_worker_outputs)) {
    unlink(worker_root, recursive = TRUE, force = TRUE)
  }

  message(
    "Parallel analysis completed with ", workers,
    " workers and ", threads_per_worker,
    " BAM thread(s) per worker."
  )
  message("Combined results saved to: ", combined_file)
  as.data.frame(combined_result)
}
