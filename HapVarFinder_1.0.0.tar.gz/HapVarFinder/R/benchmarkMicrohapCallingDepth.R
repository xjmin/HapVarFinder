#' Benchmark Microhaplotype Calling Across Read Depths
#'
#' Creates exact read-template subsets for one microhaplotype locus and measures
#' the runtime of \code{MicrohapCalling()} without changing its genotyping logic.
#' For paired-end data, a read template is a unique query name, so both mates are
#' retained together. Subset creation time is recorded separately and is not
#' included in the reported calling runtime.
#'
#' @param MH_info Path to a tab-separated locus file containing exactly one row.
#' @param bam.file Coordinate-sorted source BAM file with enough reads at the locus.
#' @param wd_link Output directory for benchmark subsets and results.
#' @param read_counts Integer vector of requested read-template counts.
#' @param replicates Number of replicate subsets per read count.
#' @param threads Threads passed to BAM indexing and to \code{MicrohapCalling()}.
#' @param seed Random seed used to sample read templates reproducibly.
#' @param samtools Path to the samtools executable. By default it is located on PATH.
#' @param keep_subsets Whether to keep the downsampled BAM files and worker output.
#' @param lian_qual Read quality threshold passed to \code{MicrohapCalling()}.
#' @param base_qual Base quality threshold passed to \code{MicrohapCalling()}.
#' @param base_qual_include Whether base-quality filtering is enabled.
#' @param other_snp_threshold Non-target SNP reporting threshold.
#' @param MH_read_threshold Minimum supporting read count for MH reporting.
#' @param MH_ratio_threshold Minimum haplotype ratio for MH calling.
#' @param SNP_ratio_threshold Minimum allele ratio for SNP calling.
#' @param PE_data Whether the source data are paired-end ("T") or single-end ("F").
#'
#' @return A data frame with requested and observed read counts, elapsed and CPU
#'   times, CPU utilization, thread/core information, R and operating-system
#'   information, and the called genotype for every benchmark run. A copy is
#'   written to \code{MicrohapCalling_depth_benchmark.tsv} in \code{wd_link}.
#'
#' @details
#' Read templates are sampled from primary, mapped, QC-passing alignments that
#' overlap the single locus. Within each replicate a single random ordering is
#' used, so smaller subsets are nested within larger subsets. Benchmark condition
#' order is randomized to reduce systematic cache effects. Peak resident memory
#' should be measured by launching each condition in a separate R process under
#' \code{/usr/bin/time -l} on macOS or \code{/usr/bin/time -v} on Linux.
#'
#' @export
benchmarkMicrohapCallingDepth <- function(
    MH_info,
    bam.file,
    wd_link,
    read_counts = c(10L, 20L, 50L, 100L, 200L, 500L, 1000L),
    replicates = 5L,
    threads = 2L,
    seed = 1L,
    samtools = Sys.which("samtools"),
    keep_subsets = TRUE,
    lian_qual = 20,
    base_qual = 30,
    base_qual_include = "T",
    other_snp_threshold = 0.01,
    MH_read_threshold = 2,
    MH_ratio_threshold = 0.25,
    SNP_ratio_threshold = 0.25,
    PE_data = "T"
) {
  if (!file.exists(MH_info)) stop("MH_info does not exist: ", MH_info)
  if (!file.exists(bam.file)) stop("bam.file does not exist: ", bam.file)
  if (!nzchar(samtools) || !file.exists(samtools)) {
    stop("samtools was not found; supply its full path via samtools=")
  }

  threads <- as.integer(threads)
  replicates <- as.integer(replicates)
  read_counts <- sort(unique(as.integer(read_counts)))
  if (length(threads) != 1L || is.na(threads) || threads < 1L) {
    stop("threads must be a single positive integer")
  }
  if (length(replicates) != 1L || is.na(replicates) || replicates < 1L) {
    stop("replicates must be a single positive integer")
  }
  if (!length(read_counts) || anyNA(read_counts) || any(read_counts < 1L)) {
    stop("read_counts must contain positive integers")
  }

  locus <- data.table::fread(MH_info, sep = "\t", header = TRUE)
  if (nrow(locus) != 1L) {
    stop("MH_info must contain exactly one locus row for a single-MH benchmark")
  }
  required_columns <- c("Chr", "Start", "End")
  missing_columns <- setdiff(required_columns, names(locus))
  if (length(missing_columns)) {
    stop("MH_info is missing columns: ", paste(missing_columns, collapse = ", "))
  }

  dir.create(wd_link, recursive = TRUE, showWarnings = FALSE)
  benchmark_root <- file.path(wd_link, "depth_benchmark_runs")
  dir.create(benchmark_root, recursive = TRUE, showWarnings = FALSE)

  bam.file <- normalizePath(bam.file, mustWork = TRUE)
  region <- sprintf(
    "%s:%s-%s",
    as.character(locus$Chr[[1L]]),
    as.integer(locus$Start[[1L]]),
    as.integer(locus$End[[1L]])
  )

  run_samtools <- function(args, stdout = FALSE) {
    stderr_file <- tempfile("samtools_stderr_", tmpdir = benchmark_root)
    on.exit(unlink(stderr_file), add = TRUE)
    ans <- system2(samtools, args = args, stdout = stdout, stderr = stderr_file)
    status <- attr(ans, "status")
    if (is.null(status)) status <- 0L
    if (!identical(as.integer(status), 0L)) {
      details <- if (file.exists(stderr_file)) {
        paste(readLines(stderr_file, warn = FALSE), collapse = "\n")
      } else ""
      stop("samtools failed (status ", status, "): ", details)
    }
    ans
  }

  ## Exclude unmapped (4), secondary (256), QC-fail (512), and supplementary
  ## (2048) alignments when selecting eligible read templates.
  excluded_flag_sum <- 4L + 256L + 512L + 2048L
  locus_sam <- run_samtools(
    c("view", "-F", excluded_flag_sum, shQuote(bam.file), shQuote(region)),
    stdout = TRUE
  )
  if (!length(locus_sam)) stop("No eligible alignments overlap ", region)

  locus_qnames <- sub("\t.*$", "", locus_sam)
  eligible_qnames <- unique(locus_qnames)
  bam_header <- run_samtools(
    c("view", "-H", shQuote(bam.file)),
    stdout = TRUE
  )
  available_templates <- length(eligible_qnames)
  if (max(read_counts) > available_templates) {
    stop(
      "The largest requested read count is ", max(read_counts),
      ", but only ", available_templates,
      " eligible read templates overlap ", region
    )
  }

  get_cpu_model <- function() {
    os <- Sys.info()[["sysname"]]
    if (identical(os, "Darwin")) {
      value <- suppressWarnings(system2(
        "sysctl", c("-n", "machdep.cpu.brand_string"), stdout = TRUE
      ))
      return(paste(value, collapse = " "))
    }
    if (identical(os, "Linux") && file.exists("/proc/cpuinfo")) {
      lines <- readLines("/proc/cpuinfo", warn = FALSE)
      model <- sub("^[^:]+:[[:space:]]*", "", grep("^model name", lines, value = TRUE))
      if (length(model)) return(model[[1L]])
    }
    NA_character_
  }

  machine <- list(
    cpu_model = get_cpu_model(),
    logical_cores = parallel::detectCores(logical = TRUE),
    physical_cores = parallel::detectCores(logical = FALSE),
    os = paste(Sys.info()[c("sysname", "release", "machine")], collapse = " "),
    r_version = R.version.string,
    package_version = tryCatch(
      as.character(utils::packageVersion("HapVarFinder")),
      error = function(e) NA_character_
    )
  )

  set.seed(seed)
  results <- vector("list", replicates * length(read_counts))
  result_index <- 1L

  for (replicate_id in seq_len(replicates)) {
    ## Smaller subsets are nested within larger subsets for each replicate.
    qname_order <- sample(eligible_qnames, available_templates, replace = FALSE)
    ## Randomizing condition order reduces systematic warm-cache effects.
    condition_order <- sample(read_counts, length(read_counts), replace = FALSE)

    for (requested_templates in condition_order) {
      run_dir <- file.path(
        benchmark_root,
        sprintf("rep_%02d_reads_%05d", replicate_id, requested_templates)
      )
      dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)

      qname_file <- file.path(run_dir, "selected_qnames.txt")
      subset_sam <- file.path(run_dir, "subset.sam")
      subset_bam <- file.path(run_dir, "subset.bam")
      locus_file <- file.path(run_dir, "single_locus.tsv")
      selected_qnames <- qname_order[seq_len(requested_templates)]
      writeLines(selected_qnames, qname_file, useBytes = TRUE)
      data.table::fwrite(locus, locus_file, sep = "\t")

      subset_start <- proc.time()
      selected_records <- locus_sam[locus_qnames %in% selected_qnames]
      writeLines(c(bam_header, selected_records), subset_sam, useBytes = TRUE)
      run_samtools(c(
        "view", "-b", "-o", shQuote(subset_bam), shQuote(subset_sam)
      ))
      run_samtools(c("index", "-@", threads, shQuote(subset_bam)))
      subset_time <- proc.time() - subset_start

      subset_region_sam <- run_samtools(
        c("view", "-F", excluded_flag_sum, shQuote(subset_bam), shQuote(region)),
        stdout = TRUE
      )
      depth_output <- run_samtools(
        c("depth", "-a", "-r", shQuote(region), shQuote(subset_bam)),
        stdout = TRUE
      )
      depth_values <- if (length(depth_output)) {
        as.numeric(sub("^([^\t]*\t){2}", "", depth_output))
      } else numeric()
      observed_qnames <- if (length(subset_region_sam)) {
        unique(sub("\t.*$", "", subset_region_sam))
      } else character()

      gc(reset = TRUE)
      calling_time <- system.time({
        call_result <- MicrohapCalling(
          MH_info = locus_file,
          bam.file = subset_bam,
          wd_link = run_dir,
          lian_qual = lian_qual,
          base_qual = base_qual,
          base_qual_include = base_qual_include,
          other_snp_threshold = other_snp_threshold,
          MH_read_threshold = MH_read_threshold,
          MH_ratio_threshold = MH_ratio_threshold,
          SNP_ratio_threshold = SNP_ratio_threshold,
          PE_data = PE_data,
          threads = threads
        )
      })

      user_seconds <- unname(calling_time[["user.self"]])
      system_seconds <- unname(calling_time[["sys.self"]])
      child_user <- if ("user.child" %in% names(calling_time)) {
        unname(calling_time[["user.child"]])
      } else 0
      child_system <- if ("sys.child" %in% names(calling_time)) {
        unname(calling_time[["sys.child"]])
      } else 0
      elapsed_seconds <- unname(calling_time[["elapsed"]])
      total_cpu_seconds <- user_seconds + system_seconds + child_user + child_system
      cpu_percent <- if (elapsed_seconds > 0) {
        100 * total_cpu_seconds / elapsed_seconds
      } else NA_real_

      results[[result_index]] <- data.frame(
        locus = if ("Tag" %in% names(locus)) as.character(locus$Tag[[1L]]) else region,
        region = region,
        replicate = replicate_id,
        requested_read_templates = requested_templates,
        observed_read_templates = length(observed_qnames),
        observed_alignments = length(subset_region_sam),
        mean_depth = if (length(depth_values)) mean(depth_values) else NA_real_,
        median_depth = if (length(depth_values)) stats::median(depth_values) else NA_real_,
        minimum_depth = if (length(depth_values)) min(depth_values) else NA_real_,
        maximum_depth = if (length(depth_values)) max(depth_values) else NA_real_,
        subset_creation_seconds = unname(subset_time[["elapsed"]]),
        elapsed_seconds = elapsed_seconds,
        user_seconds = user_seconds,
        system_seconds = system_seconds,
        child_user_seconds = child_user,
        child_system_seconds = child_system,
        total_cpu_seconds = total_cpu_seconds,
        approximate_cpu_percent = cpu_percent,
        threads_requested = threads,
        logical_cores = machine$logical_cores,
        physical_cores = machine$physical_cores,
        cpu_model = machine$cpu_model,
        operating_system = machine$os,
        r_version = machine$r_version,
        package_version = machine$package_version,
        source_bam_size_bytes = file.info(bam.file)$size,
        final_genotype = if (
          exists("call_result") &&
          "Final_Microhaplotype_Genotype" %in% names(call_result)
        ) as.character(call_result$Final_Microhaplotype_Genotype[[1L]]) else NA_character_,
        stringsAsFactors = FALSE
      )
      result_index <- result_index + 1L

      if (!isTRUE(keep_subsets)) {
        unlink(run_dir, recursive = TRUE, force = TRUE)
      }
    }
  }

  benchmark_result <- data.table::rbindlist(results, use.names = TRUE, fill = TRUE)
  data.table::setorder(
    benchmark_result,
    requested_read_templates,
    replicate
  )
  output_file <- file.path(wd_link, "MicrohapCalling_depth_benchmark.tsv")
  data.table::fwrite(benchmark_result, output_file, sep = "\t")
  message("Benchmark results saved to: ", output_file)
  as.data.frame(benchmark_result)
}

#' Benchmark Computational Scalability by Locus Count and Read Depth
#'
#' Measures the runtime of \code{MicrohapCalling()} while independently varying
#' the number of loci and the number of read templates sampled per locus. The
#' default one-factor-at-a-time design provides the two experiments needed to
#' evaluate a claim of approximately linear scaling: depth is varied while the
#' locus count is fixed, and locus count is varied while depth is fixed. An
#' optional factorial design evaluates all locus-count by read-count combinations.
#'
#' @param MH_info Tab-separated locus-definition file containing multiple loci.
#' @param bam.file Coordinate-sorted, indexed source BAM file.
#' @param wd_link Directory in which benchmark runs and result tables are stored.
#' @param locus_counts Numbers of loci to test.
#' @param read_counts Read-template counts to sample independently at each locus.
#' @param fixed_locus_count Number of loci used for the depth-scaling experiment.
#' @param fixed_read_count Read templates per locus used for the locus-scaling
#'   experiment.
#' @param design Either \code{"one_factor"} (recommended) or \code{"factorial"}.
#' @param replicates Number of independently sampled replicates per condition.
#' @param threads Threads passed to BAM sorting/indexing and
#'   \code{MicrohapCalling()}.
#' @param seed Random seed for reproducible locus and read-template sampling.
#' @param samtools Full path to samtools, or its name when available on PATH.
#' @param keep_subsets Whether to retain condition-specific BAMs and caller output.
#' @param lian_qual Read quality threshold passed to \code{MicrohapCalling()}.
#' @param base_qual Base quality threshold passed to \code{MicrohapCalling()}.
#' @param base_qual_include Whether base-quality filtering is enabled.
#' @param other_snp_threshold Non-target SNP reporting threshold.
#' @param MH_read_threshold Minimum supporting read count for MH reporting.
#' @param MH_ratio_threshold Minimum haplotype ratio for MH calling.
#' @param SNP_ratio_threshold Minimum allele ratio for SNP calling.
#' @param PE_data Whether data are paired-end ("T") or single-end ("F").
#'
#' @return Invisibly returns a list with \code{runs}, \code{summary}, and
#'   \code{models}. The same tables are written as TSV files in \code{wd_link}.
#'
#' @details
#' A read template is a unique BAM query name. For paired-end data, both mates
#' are retained when both have alignments overlapping the extracted target
#' regions; an off-target mate cannot be recovered from a coordinate-indexed
#' regional query. Within a replicate, the locus list and the
#' read-template list at every locus are randomly ordered once. Consequently,
#' smaller conditions are nested within larger conditions. Condition execution
#' order is randomized to reduce cache/order effects. Subset construction and
#' depth calculation are excluded from the reported caller runtime.
#'
#' The fitted models are \code{elapsed_seconds ~ requested_read_templates_per_locus}
#' for depth scaling and \code{elapsed_seconds ~ requested_loci} for locus scaling.
#' For the factorial design an additional model with their interaction is fitted.
#' Inspect slopes, 95-percent confidence intervals, residual plots, and R-squared
#' before describing performance as linear. Peak RAM requires isolated processes
#' and should be measured separately with \code{/usr/bin/time -l} (macOS) or
#' \code{/usr/bin/time -v} (Linux).
#'
#' @export
benchmarkMicrohapCallingScalability <- function(
    MH_info,
    bam.file,
    wd_link,
    locus_counts = c(1L, 5L, 10L, 20L, 50L, 100L),
    read_counts = c(10L, 20L, 50L, 100L, 200L, 500L, 1000L),
    fixed_locus_count = 10L,
    fixed_read_count = 100L,
    design = c("one_factor", "factorial"),
    replicates = 5L,
    threads = 1L,
    seed = 1L,
    samtools = Sys.which("samtools"),
    keep_subsets = FALSE,
    lian_qual = 20,
    base_qual = 30,
    base_qual_include = "T",
    other_snp_threshold = 0.01,
    MH_read_threshold = 2,
    MH_ratio_threshold = 0.25,
    SNP_ratio_threshold = 0.25,
    PE_data = "T"
) {
  design <- match.arg(design)
  if (!file.exists(MH_info)) stop("MH_info does not exist: ", MH_info)
  if (!file.exists(bam.file)) stop("bam.file does not exist: ", bam.file)
  if (!nzchar(samtools) || !file.exists(samtools)) {
    stop("samtools was not found; supply its full path via samtools=")
  }

  positive_integers <- function(x, label) {
    x <- sort(unique(as.integer(x)))
    if (!length(x) || anyNA(x) || any(x < 1L)) {
      stop(label, " must contain positive integers")
    }
    x
  }
  locus_counts <- positive_integers(locus_counts, "locus_counts")
  read_counts <- positive_integers(read_counts, "read_counts")
  fixed_locus_count <- positive_integers(fixed_locus_count, "fixed_locus_count")
  fixed_read_count <- positive_integers(fixed_read_count, "fixed_read_count")
  replicates <- positive_integers(replicates, "replicates")
  threads <- positive_integers(threads, "threads")
  if (length(fixed_locus_count) != 1L || length(fixed_read_count) != 1L ||
      length(replicates) != 1L || length(threads) != 1L) {
    stop("fixed_locus_count, fixed_read_count, replicates, and threads must be scalars")
  }

  loci <- data.table::fread(MH_info, sep = "\t", header = TRUE)
  required_columns <- c("Chr", "Start", "End")
  missing_columns <- setdiff(required_columns, names(loci))
  if (length(missing_columns)) {
    stop("MH_info is missing columns: ", paste(missing_columns, collapse = ", "))
  }
  maximum_loci <- if (design == "factorial") max(locus_counts) else {
    max(c(locus_counts, fixed_locus_count))
  }
  if (maximum_loci > nrow(loci)) {
    stop("Requested ", maximum_loci, " loci, but MH_info contains ", nrow(loci))
  }

  dir.create(wd_link, recursive = TRUE, showWarnings = FALSE)
  benchmark_root <- file.path(wd_link, "scalability_benchmark_runs")
  dir.create(benchmark_root, recursive = TRUE, showWarnings = FALSE)
  bam.file <- normalizePath(bam.file, mustWork = TRUE)

  run_samtools <- function(args, stdout = FALSE) {
    stderr_file <- tempfile("samtools_stderr_", tmpdir = benchmark_root)
    on.exit(unlink(stderr_file), add = TRUE)
    answer <- system2(samtools, args = args, stdout = stdout, stderr = stderr_file)
    status <- attr(answer, "status")
    if (is.null(status)) status <- 0L
    if (as.integer(status) != 0L) {
      details <- if (file.exists(stderr_file)) {
        paste(readLines(stderr_file, warn = FALSE), collapse = "\n")
      } else ""
      stop("samtools failed (status ", status, "): ", details)
    }
    answer
  }

  excluded_flag_sum <- 4L + 256L + 512L + 2048L
  regions <- sprintf("%s:%d-%d", loci$Chr, as.integer(loci$Start), as.integer(loci$End))
  message("Reading eligible alignments for ", maximum_loci, " candidate loci ...")
  locus_sam <- lapply(seq_len(maximum_loci), function(i) {
    run_samtools(
      c("view", "-F", excluded_flag_sum, shQuote(bam.file), shQuote(regions[[i]])),
      stdout = TRUE
    )
  })
  locus_qnames <- lapply(locus_sam, function(x) sub("\t.*$", "", x))
  eligible_qnames <- lapply(locus_qnames, unique)
  maximum_reads <- if (design == "factorial") max(read_counts) else {
    max(c(read_counts, fixed_read_count))
  }
  insufficient <- which(lengths(eligible_qnames) < maximum_reads)
  if (length(insufficient)) {
    stop(
      "The following candidate locus row(s) have fewer than ", maximum_reads,
      " eligible templates: ", paste(insufficient, collapse = ", "),
      ". Reduce read_counts/fixed_read_count or reorder/filter MH_info."
    )
  }
  bam_header <- run_samtools(c("view", "-H", shQuote(bam.file)), stdout = TRUE)

  if (design == "one_factor") {
    conditions <- unique(rbind(
      data.frame(
        experiment = "depth_scaling",
        requested_loci = fixed_locus_count,
        requested_read_templates_per_locus = read_counts
      ),
      data.frame(
        experiment = "locus_scaling",
        requested_loci = locus_counts,
        requested_read_templates_per_locus = fixed_read_count
      )
    ))
  } else {
    conditions <- expand.grid(
      requested_loci = locus_counts,
      requested_read_templates_per_locus = read_counts,
      KEEP.OUT.ATTRS = FALSE,
      stringsAsFactors = FALSE
    )
    conditions$experiment <- "factorial"
    conditions <- conditions[, c("experiment", "requested_loci",
                                  "requested_read_templates_per_locus")]
  }

  cpu_model <- function() {
    if (identical(Sys.info()[["sysname"]], "Darwin")) {
      return(paste(suppressWarnings(system2(
        "sysctl", c("-n", "machdep.cpu.brand_string"), stdout = TRUE
      )), collapse = " "))
    }
    if (file.exists("/proc/cpuinfo")) {
      z <- grep("^model name", readLines("/proc/cpuinfo", warn = FALSE), value = TRUE)
      if (length(z)) return(sub("^[^:]+:[[:space:]]*", "", z[[1L]]))
    }
    NA_character_
  }
  machine <- list(
    cpu_model = cpu_model(),
    logical_cores = parallel::detectCores(logical = TRUE),
    physical_cores = parallel::detectCores(logical = FALSE),
    os = paste(Sys.info()[c("sysname", "release", "machine")], collapse = " "),
    r_version = R.version.string,
    package_version = tryCatch(
      as.character(utils::packageVersion("HapVarFinder")),
      error = function(e) NA_character_
    )
  )

  set.seed(seed)
  results <- vector("list", nrow(conditions) * replicates)
  result_index <- 1L
  for (replicate_id in seq_len(replicates)) {
    locus_order <- sample(seq_len(maximum_loci), maximum_loci, replace = FALSE)
    qname_orders <- lapply(eligible_qnames, sample, replace = FALSE)
    condition_order <- sample(seq_len(nrow(conditions)))

    for (condition_index in condition_order) {
      condition <- conditions[condition_index, ]
      selected_locus_indices <- locus_order[seq_len(condition$requested_loci)]
      requested_reads <- condition$requested_read_templates_per_locus
      run_dir <- file.path(
        benchmark_root,
        sprintf(
          "rep_%02d_%s_loci_%04d_reads_%05d",
          replicate_id, condition$experiment, condition$requested_loci, requested_reads
        )
      )
      dir.create(run_dir, recursive = TRUE, showWarnings = FALSE)
      locus_file <- file.path(run_dir, "loci.tsv")
      subset_sam <- file.path(run_dir, "subset.sam")
      unsorted_bam <- file.path(run_dir, "subset.unsorted.bam")
      subset_bam <- file.path(run_dir, "subset.bam")
      data.table::fwrite(loci[selected_locus_indices], locus_file, sep = "\t")

      subset_start <- proc.time()
      selected_records <- unlist(lapply(selected_locus_indices, function(i) {
        selected_names <- qname_orders[[i]][seq_len(requested_reads)]
        locus_sam[[i]][locus_qnames[[i]] %in% selected_names]
      }), use.names = FALSE)
      selected_records <- unique(selected_records)
      writeLines(c(bam_header, selected_records), subset_sam, useBytes = TRUE)
      run_samtools(c("view", "-b", "-o", shQuote(unsorted_bam), shQuote(subset_sam)))
      run_samtools(c("sort", "-@", threads, "-o", shQuote(subset_bam),
                     shQuote(unsorted_bam)))
      run_samtools(c("index", "-@", threads, shQuote(subset_bam)))
      subset_seconds <- unname((proc.time() - subset_start)[["elapsed"]])

      observed_templates <- numeric(length(selected_locus_indices))
      mean_depths <- numeric(length(selected_locus_indices))
      for (j in seq_along(selected_locus_indices)) {
        i <- selected_locus_indices[[j]]
        observed_sam <- run_samtools(
          c("view", "-F", excluded_flag_sum, shQuote(subset_bam),
            shQuote(regions[[i]])), stdout = TRUE
        )
        observed_templates[[j]] <- length(unique(sub("\t.*$", "", observed_sam)))
        depth_lines <- run_samtools(
          c("depth", "-a", "-r", shQuote(regions[[i]]), shQuote(subset_bam)),
          stdout = TRUE
        )
        depth_values <- if (length(depth_lines)) {
          as.numeric(sub("^([^\t]*\t){2}", "", depth_lines))
        } else numeric()
        mean_depths[[j]] <- if (length(depth_values)) mean(depth_values) else 0
      }

      gc(reset = TRUE)
      calling_time <- system.time({
        call_result <- MicrohapCalling(
          MH_info = locus_file, bam.file = subset_bam, wd_link = run_dir,
          lian_qual = lian_qual, base_qual = base_qual,
          base_qual_include = base_qual_include,
          other_snp_threshold = other_snp_threshold,
          MH_read_threshold = MH_read_threshold,
          MH_ratio_threshold = MH_ratio_threshold,
          SNP_ratio_threshold = SNP_ratio_threshold,
          PE_data = PE_data, threads = threads
        )
      })
      elapsed <- unname(calling_time[["elapsed"]])
      user <- unname(calling_time[["user.self"]])
      system <- unname(calling_time[["sys.self"]])
      child_user <- if ("user.child" %in% names(calling_time)) {
        unname(calling_time[["user.child"]])
      } else 0
      child_system <- if ("sys.child" %in% names(calling_time)) {
        unname(calling_time[["sys.child"]])
      } else 0
      total_cpu <- user + system + child_user + child_system

      results[[result_index]] <- data.frame(
        experiment = condition$experiment,
        replicate = replicate_id,
        random_seed = seed,
        requested_loci = condition$requested_loci,
        requested_read_templates_per_locus = requested_reads,
        requested_total_locus_templates = condition$requested_loci * requested_reads,
        selected_locus_rows = paste(selected_locus_indices, collapse = ","),
        selected_locus_ids = paste(
          if ("Tag" %in% names(loci)) {
            as.character(loci$Tag[selected_locus_indices])
          } else regions[selected_locus_indices],
          collapse = ","
        ),
        observed_templates_per_locus_mean = mean(observed_templates),
        observed_templates_per_locus_minimum = min(observed_templates),
        observed_mean_depth = mean(mean_depths),
        observed_median_locus_depth = stats::median(mean_depths),
        subset_creation_seconds = subset_seconds,
        elapsed_seconds = elapsed,
        user_seconds = user,
        system_seconds = system,
        child_user_seconds = child_user,
        child_system_seconds = child_system,
        total_cpu_seconds = total_cpu,
        approximate_cpu_percent = if (elapsed > 0) 100 * total_cpu / elapsed else NA_real_,
        returned_loci = if (exists("call_result")) nrow(call_result) else NA_integer_,
        threads_requested = threads,
        logical_cores = machine$logical_cores,
        physical_cores = machine$physical_cores,
        cpu_model = machine$cpu_model,
        operating_system = machine$os,
        r_version = machine$r_version,
        package_version = machine$package_version,
        source_bam_size_bytes = file.info(bam.file)$size,
        stringsAsFactors = FALSE
      )
      result_index <- result_index + 1L
      if (!isTRUE(keep_subsets)) unlink(run_dir, recursive = TRUE, force = TRUE)
    }
  }

  runs <- data.table::rbindlist(results, use.names = TRUE, fill = TRUE)
  data.table::setorder(runs, experiment, requested_loci,
                       requested_read_templates_per_locus, replicate)
  condition_summary <- runs[, .(
    n_replicates = .N,
    elapsed_mean_seconds = mean(elapsed_seconds),
    elapsed_sd_seconds = stats::sd(elapsed_seconds),
    elapsed_median_seconds = stats::median(elapsed_seconds),
    elapsed_q1_seconds = stats::quantile(elapsed_seconds, 0.25, names = FALSE),
    elapsed_q3_seconds = stats::quantile(elapsed_seconds, 0.75, names = FALSE),
    mean_cpu_percent = mean(approximate_cpu_percent, na.rm = TRUE),
    mean_observed_depth = mean(observed_mean_depth)
  ), by = .(experiment, requested_loci, requested_read_templates_per_locus)]

  tidy_lm <- function(model, model_name) {
    coefficients <- summary(model)$coefficients
    intervals <- stats::confint(model)
    data.frame(
      model = model_name,
      term = rownames(coefficients),
      estimate = coefficients[, "Estimate"],
      standard_error = coefficients[, "Std. Error"],
      statistic = coefficients[, "t value"],
      p_value = coefficients[, "Pr(>|t|)"],
      confidence_low_95 = intervals[, 1L],
      confidence_high_95 = intervals[, 2L],
      r_squared = summary(model)$r.squared,
      adjusted_r_squared = summary(model)$adj.r.squared,
      stringsAsFactors = FALSE,
      row.names = NULL
    )
  }
  model_tables <- list()
  if (design == "one_factor") {
    depth_data <- runs[runs$experiment == "depth_scaling", ]
    locus_data <- runs[runs$experiment == "locus_scaling", ]
    if (length(unique(depth_data$requested_read_templates_per_locus)) >= 2L) {
      model_tables$depth <- tidy_lm(
        stats::lm(elapsed_seconds ~ requested_read_templates_per_locus,
                  data = depth_data), "depth_scaling"
      )
    }
    if (length(unique(locus_data$requested_loci)) >= 2L) {
      model_tables$locus <- tidy_lm(
        stats::lm(elapsed_seconds ~ requested_loci, data = locus_data),
        "locus_scaling"
      )
    }
  } else {
    model_tables$factorial <- tidy_lm(
      stats::lm(elapsed_seconds ~ requested_loci *
                  requested_read_templates_per_locus, data = runs),
      "factorial_interaction"
    )
  }
  models <- if (length(model_tables)) {
    data.table::rbindlist(model_tables, use.names = TRUE, fill = TRUE)
  } else data.table::data.table()

  run_file <- file.path(wd_link, "MicrohapCalling_scalability_runs.tsv")
  summary_file <- file.path(wd_link, "MicrohapCalling_scalability_summary.tsv")
  model_file <- file.path(wd_link, "MicrohapCalling_scalability_models.tsv")
  data.table::fwrite(runs, run_file, sep = "\t")
  data.table::fwrite(condition_summary, summary_file, sep = "\t")
  data.table::fwrite(models, model_file, sep = "\t")
  message("Scalability run data saved to: ", run_file)
  message("Condition summaries saved to: ", summary_file)
  message("Regression results saved to: ", model_file)
  invisible(list(
    runs = as.data.frame(runs),
    summary = as.data.frame(condition_summary),
    models = as.data.frame(models)
  ))
}
