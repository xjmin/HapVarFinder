#' Compute Core Forensic Statistics
#'
#' Computes expected heterozygosity, polymorphism information content,
#' effective number of alleles, discrimination power, and probability of
#' exclusion from a vector of allele frequencies.
#'
#' @param alle_freq Numeric vector of allele frequencies. Values must be between
#'   zero and one; values are normalized with a warning when they do not sum to
#'   one within floating-point tolerance.
#' @return A named character vector containing `he`, `pic`, `ae`, `dp`, and
#'   `pe`, rounded to six decimal places.
#' @examples
#' computeForensicStats(c(0.4, 0.3, 0.2, 0.1))
#' @name computeForensicStats
#' @usage computeForensicStats(alle_freq)
NULL
