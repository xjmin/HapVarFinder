# HapVarFinder

HapVarFinder is an R package for reconstructing and genotyping
microhaplotypes and other multivariant markers from aligned sequencing reads.
It supports single-source and mixture analysis, quality assessment,
population-level summaries, forensic statistics, data conversion,
computational benchmarking, locus-level parallel processing, and an
interactive Shiny interface.

## Main functions

- `MicrohapCalling()`: haplotype calling for single-source samples.
- `MixMicrohapCall()`: haplotype calling for mixture samples.
- `parallelMicrohapCalling()`: locus-level parallel calling.
- `analyzeMicrohaplotypeResults()`: quality assessment of calling results.
- `recalculateMHcallsByThreshold()`: threshold-based recalculation.
- `popMicroHapFreq()`: population haplotype-frequency estimation.
- `computeForensicStats()` and `computeForensicStatsDetailed()`: marker
  statistics.
- `toIndReference()`, `toEuroforMixInput()`, and
  `toEuroForMixFreqData()`: downstream format conversion.
- `benchmarkMicrohapCallingDepth()` and
  `benchmarkMicrohapCallingScalability()`: runtime benchmarking.
- `runHapVarFinder()`: launch the Shiny application.

## Installation

Install the source archive from R:

```r
install.packages("HapVarFinder_1.0.0.tar.gz", repos = NULL, type = "source")
library(HapVarFinder)
```

Launch the graphical interface with:

```r
runHapVarFinder()
```

The legacy function `runHapFinder()` is retained as a compatibility alias.

## Documentation

See `docs/HapVarFinder_Function_Guide.pdf` for an overview of inputs,
workflows, functions, parallel execution, and benchmarking.

## License

GPL-3.
